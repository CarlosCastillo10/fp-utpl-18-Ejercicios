/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Administrador
 */
public class Ejemplo4 {
    
    public static void main(String[] args) {
        /**String mensaje = "Hola";
        String mensaje2 = "Mundo";
        //System.out.println(mensaje+"\n"+mensaje2);
        System.out.printf("%s\n\t%s",mensaje,mensaje2);
        */
        String nombre = "Carlos";
        String apellido = "Castillo";
        int edad =20;
        Double valor_celular = 250.75;
        System.out.printf("%s\n\t%sEdad:%d\nValor: %f\n",nombre,apellido,edad,valor_celular);
        
        
    }
    
}
