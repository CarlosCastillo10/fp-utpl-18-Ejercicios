/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Administrador
 */
public class Ejemplo2 {
    
    public static void main(String[] args) {
        String mensaje = "Hola";
        String mensaje2 = "Mundo";
        System.out.println(mensaje+"/n"+mensaje2);
        
    }
    
}
