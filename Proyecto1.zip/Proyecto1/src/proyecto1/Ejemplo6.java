/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

import java.util.Scanner;
/**
 *
 * @author Administrador
 */
public class Ejemplo6 {
    
    public static void main(String[] args) {
        /**String mensaje = "Hola";
        String mensaje2 = "Mundo";
        //System.out.println(mensaje+"\n"+mensaje2);
        System.out.printf("%s\n\t%s",mensaje,mensaje2);
        */
        Scanner entrada = new Scanner(System.in);
        String nombre;
        String apellido;
        
        System.out.println("Ingrese valor para su nombre");
        nombre = entrada.nextLine();
        
        System.out.println("Ingrese valor para su apellido");
        apellido = entrada.nextLine();
        
        System.out.printf("Su nombre es: %s\nSu apellido es: %s\n",nombre,apellido);
   

        
    }
    
}
